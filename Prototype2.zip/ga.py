#Import modules for elementwize problem
#from _typeshed import Self
from typing import ValuesView
import numpy as np
import autograd.numpy as anp
from pymoo.util.misc import stack
from pymoo.core.problem import ElementwiseProblem ,starmap_parallelized_eval

#Import modules for DE
from pymoo.algorithms.soo.nonconvex.de import DE
from pymoo.operators.sampling.lhs import LHS
from pymoo.optimize import minimize
from pymoo.factory import get_termination

#import for Paralellization
import multiprocessing
from multiprocessing.pool import ThreadPool
import threading

#Import for fileNames
import uuid

#import for function
import callCarlSAT as call
import ancestry as anc

count = 0
cTime = 0
scoreLow = 1000000
selectionArray = []
inLow = "words"
lock = threading.Lock()

# pool is a global variable, that will not change during run
n_threads = multiprocessing.cpu_count()
pool = ThreadPool(n_threads)

#Define elementwise problem
class MyProblem(ElementwiseProblem):
    def __init__(self, *args, **kwargs):

        #20 values the problem will choose (0-19) for each parameter
        self.const_a = np.logspace(0, 3, 20)
        self.const_b = np.logspace(1, 6, 20)
        self.const_c = np.logspace(0, 3, 20)                   
        self.const_e = np.logspace(0, 3, 20)      
        self.const_f = np.logspace(0, 3, 20)                     
        self.const_r = np.logspace(0, 2, 20)
        self.const_x = np.logspace(0, 5, 20)
        
        # Obtain the args (filename and timeout) passed from the GA 
        self.initVar = args

        super().__init__(n_var=7,  
                         n_obj=2,
                         n_constr=0,
                         #                a        b     c      e     f     r       x    # we're picking from a list
                         xl = np.array([  0,       0,    0,     0,    0,    0,      0]), # lower bounds of vars
                         xu = np.array([ 19,  19,  19,   19,  19,   19,  19]), # upper bounds of vars
                         **kwargs
                         )


    def _evaluate(self, x, out , *args, **kwaargs):  #x is the list of parameters supplied by the GA algorithm (in this case DE)
        a =    int(self.const_a[round(x[0])])
        b =    int(self.const_b[round(x[1])])
        c =    int(self.const_c[round(x[2])])
        e =    int(self.const_e[round(x[3])])
        f =    int(self.const_f[round(x[4])])
        r =    int(self.const_r[round(x[5])])
        topx = int(self.const_x[round(x[6])])
        v = 3 

        # Obtain file name and timeout from the initialization of the function
        filetime = self.initVar[0]
        
        # Make an array of type int using the variables provided by the GA
        arr = [a,b,c,e,f,r,topx,v]
        arr = list(map(str, arr))

        # Create a outfile to write to using a UUID
        outfile = str(uuid.uuid4()) + ".out"

        # Global variables for parallelization of the prototype
        global count, scoreLow, inLow, selectionArray

        # If the count is less than 33 (For the first 32 runs of the GA)
        # The input file is the file provided by the user
        # Else the input file is the out file created
        count+=1
        if count<33:
            inputFile = filetime[0]
        else:
            inputFile = inLow
        arr.append(outfile)

        arrayC = call.callCarlSAT(inputFile, arr, filetime[1])
        ancestryArray = arr
        inLow = arrayC[len(arrayC)-1]

        if (len(arrayC)==3):
            if arrayC[0] < scoreLow:
                lock.acquire()
                inLow = outfile
                lock.release()
            p1 = arrayC[0]
            out["F"] = p1
            
        elif (len(arrayC)==5):
            if arrayC[0] < scoreLow:
                lock.acquire()
                inLow = outfile
                lock.release()
            p1 = arrayC[1]
            p2 = arrayC[1]- arrayC[0]
            p3 = arrayC[3]- arrayC[2]
            out["F"] = p1

        anc.writeToAncestry(ancestryArray,filetime[0])

# Genetic algorithm
def geneticAlgorithm(filename, timeout):

    # Test whether filename and timeout is valid
    if (filename.find(".wcard") == -1):
        raise TypeError("Filename is incorrect")
    
    if (timeout != "1" and timeout != "2" and timeout != "10"):                     # If the timeout is not "1","2" or "10", send an error with the correct syntax
        raise ValueError("Timeout must be either 1, 2 or 10")

    # Initialize problem
    initVar = [filename, timeout]
    problem = MyProblem(initVar, runner=pool.starmap, func_eval=starmap_parallelized_eval)         # Problem assignment, with parallelization using starmap 

    termination = get_termination("n_gen", 32)                               # After 32 Generations, stop the pymoo

    # Initialize algorithm
    algorithm = DE(
        pop_size= 32,                                                        # 32 this is the number of items that are sampled per generation. Each generation, the best go though, and are used to construct new offspring.
        sampling=LHS(), # Defines the initial set of solutions which are the starting point of the optimization
        variant="DE/rand/1/bin",                                             # The different variants of DE to be used.
        CR=0.5,                                                              # Probability the individual exchanges variable values from the donor vector
        F=0.3,                                                               # Crossover weight
        dither="vector",                                                     # Different individual used one for each individual
        jitter=False                                                         # Strategy for adaptive weights (F). A very small value is added or subtracted to the weight used for the crossover for each individual
    )


    #Optimize with minimize
    res = minimize(problem,                                                  # The problem defined above
                algorithm,                                                   # The algorithm provided by pymoo
                termination,                                                 # Tells the program when it needs to stop running
                seed = 1,                                                    # Tells the 
                save_history = True,                                         # For diagnostics
                verbose = True                                               # Shows the programs processing if set to 'True'
    )
    return res.X
