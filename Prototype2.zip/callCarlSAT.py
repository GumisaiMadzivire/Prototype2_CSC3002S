# callCarlSAT script for prototype 2
# Gumisai Madzivire & Masechaba Khoza
# MDZGUM002 KHZMAS001

# Imports for process execution
import subprocess
import os

# Function used to call carlSAT program
# Main functionality to obtain results from the provided wcard
# Extended to allow for optimization of statefiles as well
def callCarlSAT(filename, arrParms, timeout):
    a = arrParms[0] #"2"
    b = arrParms[1] #"4"
    c = arrParms[2] 
    e = arrParms[3] 
    f = arrParms[4] 
    r = arrParms[5] 
    x = arrParms[6] 
    t = timeout
    v = arrParms[7] # should always be "3"
    z = filename
    w = arrParms[8]

    outFile = ".out"

    m = str(float(t)*1000/32)
    t = str(float(m)/1000)

    #If we find .out within the input filename, we use CarlSAT2's functionality
    if outFile in z:
        process = subprocess.run([os.path.join(os.getcwd(), 'CarlSAT'), '-a', a, '-b', b, '-c', c, '-e', e, '-f', f, '-r', r, '-x', x, '-m', m, '-v', v, '-i', z, '-w', w], cwd = os.getcwd(),
    capture_output=True).stdout
    #else we use the base functionality from CarlSAT1
    else:
        process = subprocess.run([os.path.join(os.getcwd(), 'CarlSAT'), '-a', a, '-b', b, '-c', c, '-e', e, '-f', f, '-r', r, '-x', x, '-t', t, '-v', v, '-z', z, '-w', w], cwd = os.getcwd(),
    capture_output=True).stdout

    #conversion of bytes to string
    data = process.decode()
    
    data = data[data.find(".out")+4:-1]

    outExists = data.find(".out")

    carlSATOutArray = data.split()

    # If out is found within the first line of CarlSAT we use the CarlSAT2's functionality
    if (outExists != -1):
        startCostIndex = carlSATOutArray.index("Intermediate:") +3   #A
        strStartCost = carlSATOutArray[startCostIndex]
        startCost = int(strStartCost.replace(',',''), base=10)

        endCostIndex = carlSATOutArray.index("UNKNOWN")+2            #B
        strEndCost = carlSATOutArray[endCostIndex]
        endCost = int(strEndCost.replace(',',''), base=10)

        timeToScoreIndex = carlSATOutArray.index("Time:")+1          #C
        timeToScore = carlSATOutArray[timeToScoreIndex]
        tts = round(float(timeToScore)*1000, 3)

        timeoutIndex = carlSATOutArray.index("Timeout") +2           #D
        strTimeout = carlSATOutArray[timeoutIndex]
        timeout = int(strTimeout.replace(',',''), base=10)

        obj = [startCost, endCost, tts, timeout, w]
        return obj

    # else we use CarlSAT's base functionality
    else:
        strCostIndex = carlSATOutArray.index('o')+1
        strCost = carlSATOutArray[strCostIndex]
        cost = int(strCost.replace(',',''), base=10)

        #converting time to float
        strTimeIndex = carlSATOutArray.index("Time:")+1
        strTime = carlSATOutArray[strTimeIndex]
        time = float(strTime)

        obj = [cost, time, w]
    
        return obj