# driver script for prototype2
# Gumisai Madzivire & Masechaba Khoza
# MDZGUM002 KHZMAS001

# Imports for driver.py functionality
import sys
import ancestry as a
import ga as ga
import os
import database as db

# main function
# This is the function that the user interacts with directly and is the driver of the program
if __name__ == '__main__':

    n = len(sys.argv)
    if (n == 3):

        # Get user input and store in filename and timeout
        filename = sys.argv[1]                                                              # Gets the filename from the second argument passed in the console
        timeout = sys.argv[2]                                                               # Gets the timeout from the third argument passed in the console

        if (filename.find(".wcard") == -1):                                                 # If the filename does not contain .wcard, send an error with the correct syntax
            raise TypeError("Correct syntax is \'python3 prototype1 [wcard] [timeout]\'")

        if (timeout != "1" and timeout != "2" and timeout != "10"):                           # If the timeout is not "1","2" or "10", send an error with the correct syntax
            raise ValueError("Timeout must be either 1, 2 or 10")

        print("Starting HyperOptimizer....")

        # create database and tables for use in the hyperoptimizer
        dB = db.createDatabase()
        db.createTable(filename)

        # create an output file for the ancestry data of the hyperoptimizer
        a.createAncestryFile(filename)
        output = ga.geneticAlgorithm(filename, timeout)
        output = output.round()
        arr = output.tolist()

        target = "/ramdisk/"

        os.system("mv *.out "+ target)

    else:
        raise SyntaxError("Correct syntax to start is \'python3 prototype1 [wcard] [timeout]\'")