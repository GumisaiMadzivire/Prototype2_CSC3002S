import mysql.connector

def createDatabase():
    db = mysql.connector.connect(
        host="localhost",
        user="me",
        password="me"
    )

    mycursor = db.cursor()
    code = "CREATE DATABASE IF NOT EXISTS statefiles"

    mycursor.execute(code)

    return db

def createTable(filename):
    db = mysql.connector.connect(
        host="localhost",
        user="me",
        password="me"
    )

    mycursor = db.cursor()
    mycursor.execute("USE statefiles;")
    code = "CREATE TABLE IF NOT EXISTS test (id varchar(255) primary key not null, thread_id integer not null, a varchar(255), b varchar(255), c varchar(255), d varchar(255));"
    mycursor.execute(code)

    code = "CREATE TABLE IF NOT EXISTS ids ( id integer primary key auto_increment not null, thread_id varchar(255) not null );"
    mycursor.execute(code)
    db.close()

def addToTable(thread_id, arr):
    db = mysql.connector.connect(
        host="localhost",
        user="me",
        password="me"
    )

    mycursor = db.cursor()
    mycursor.execute("USE statefiles;")

    code = ("SELECT thread_id FROM ids WHERE thread_id = "+str(thread_id)+" ORDER BY id DESC LIMIT 1;")
    mycursor.execute(code)
    id = mycursor.fetchone()
    
    code = ("INSERT INTO test (id, thread_id, a, b, c, d) VALUES ({%s}{%s}{%s}{%s}{%s}{%s});",(arr[0],id,arr[1],arr[2],arr[3]))

    mycursor.execute(code)
    db.commit()
    db.close()

def addToThreadTable(thread):
    db = mysql.connector.connect(
        host="localhost",
        user="me",
        password="me",
        database="statefiles"
    )

    mycursor = db.cursor()

    code = "INSERT IGNORE INTO ids (thread_id) VALUES ("+ str(thread) +");"

    mycursor.execute(code)
    
    db.commit()
    db.close()
