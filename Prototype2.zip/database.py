# database script for prototype2
# Gumisai Madzivire & Masechaba Khoza
# MDZGUM002 KHZMAS001

# Import allowing access to MySQL Database
import mysql.connector

# Function creates a database for use throughout prototype 2
def createDatabase():
    db = mysql.connector.connect(
        host="localhost",
        user="me",
        password="me"
    )

    mycursor = db.cursor()
    code = "CREATE DATABASE IF NOT EXISTS statefiles"

    mycursor.execute(code)
    db.close()

# Function creates 2 tables:
# 1. ids table stores the thread_id for use in the main test table
# 2. test table stores the thread_id, filename, best score, delta score (improvement in score), stuck time,
# and d, the search criterion for the least squares calculation
def createTable(filename):
    db = mysql.connector.connect(
        host="localhost",
        user="me",
        password="me"
    )

    mycursor = db.cursor()
    mycursor.execute("USE statefiles;")
    code = "CREATE TABLE IF NOT EXISTS test (id integer auto_increment primary key not null, thread_id varchar(255) not null, filename varchar(255), a varchar(255), b varchar(255), c varchar(255), d varchar(255));"
    mycursor.execute(code)

    code = "CREATE TABLE IF NOT EXISTS ids ( id integer primary key auto_increment not null, thread_id varchar(255) not null );"
    mycursor.execute(code)
    db.close()

# Function adds values to tables
# First by ensuring that a thread belongs to a single tuple
# and allocating the respective variables to that tuple
def addToTable(thread_id, arr):
    db = mysql.connector.connect(
        host="localhost",
        user="me",
        password="me",
        autocommit = True
    )

    mycursor = db.cursor()
    mycursor.execute("USE statefiles;")

    code = ("SELECT thread_id FROM ids WHERE thread_id = (%s) ORDER BY id DESC LIMIT 1;")
    mycursor.execute(code,(str(thread_id),))
    idtuple = mycursor.fetchone()
    id = str(idtuple[0])

    f=arr[0]
    a=arr[1]
    b=arr[2]
    c=arr[3]
    d=arr[4]

    code = "INSERT INTO test (thread_id, filename, a, b, c, d) VALUES ((%s),(%s),(%s),(%s),(%s),(%s));"
    mycursor.execute(code,((id,f,a,b,c,d)), multi = True)

    db.commit()
    db.close()

# Function adds Thread IDs to ids table
# Allowing identification of threads useful for the function above
# Will only store n threads (where n is the number of cpus on the machine)
def addToThreadTable(thread):
    db = mysql.connector.connect(
        host="localhost",
        user="me",
        password="me",
        database="statefiles"
    )

    mycursor = db.cursor()

    code = """INSERT IGNORE INTO ids (thread_id) VALUES (%s);"""

    mycursor.execute(code, (str(thread),))
    
    db.commit()
    db.close()

# Pulls table data for use within ga.py
def pullFromTest(thread):
    db = mysql.connector.connect(
        host="localhost",
        user="me",
        password="me",
        database="statefiles"
    )
    mycursor = db.cursor()

    code = "SELECT filename FROM test WHERE thread_id = "+str(thread)+" ORDER BY id LIMIT 1"
    mycursor.execute(code)
    name = mycursor.fetchone()
    db.close()

    return name
