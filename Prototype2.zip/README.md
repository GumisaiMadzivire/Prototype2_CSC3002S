#prototype2.md

This serves as a guide to using the prototype 2
Step 1: Build the Dockerfile contained within this directory with the following command "docker build -t prototype2 ." 
Step 2: Run the Dockerfile using "docker run -it prototype1". This should take you to the folder where prototype1 as well as CarlSAT have been saved within docker
Step 3: Add the user for the database in prototype2 by using these commands:\

    service mysql start # if this happens to not work, try running this line again
    mysql -u root -p # allows access to the mysql database using the root user

    # At this stage you will be prompted for a password:
    # i.e.
sys Enter password: 

    #The password is root. Be careful when typing, as your characters will not show as you type

    #After this you will be prompted with this output for mysql
sys mysql> 
    
    # Type in each of these commands so that you can use the database defined in prototype2
    USE mysql;
    CREATE USER 'me'@'localhost' IDENTIFIED BY 'me';
    GRANT ALL PRIVILEGES ON *.* TO 'me'@'localhost';
    exit;

    # You should be back at the normal terminal inside docker

Step 4: Run the program by typing this within the current Directory "python3 driver.py [wcard] [timeout]"
    where
        [wcard] is the test file of your choosing
        [timeout] is the timeout associated with the test prefix

    This will cause the program to run, making statefiles in the current directory, and outputting the stucktime, improvement in score and current score
        to a database called statefiles held within mysql
    This will also cause the program to write the statefile and the variables used by carlSAT corresponding to the statefile in a text file bearing the same
        name as the test file 

Step 5: Check lineage of the database by running these commands in order
    mysql -u me -p
    me
    USE statefiles;
    SELECT * FROM test;     # Shows the id number, thread_id of the creating thread, filename, best score, improvement in score, stucktime and a value to optimise them all
    SELECT * FROM ids;      # Shows the id number and the thread_id of all existing threads for that specific run;

Step 6: To repeat runs
    DROP TABLE test;
    DROP TABLE ids;
    exit;

    #this will take you out of mysql runs

    repeat Steps 4 and 5 as necessary

Exit whenever you want by typing exit within docker's main console

Happy testing ;)



