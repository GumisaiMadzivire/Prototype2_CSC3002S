service mysql start
service mysql start
mysql -u root
USE mysql;
CREATE USER 'me'@'localhost' IDENTIFIED BY 'me';
GRANT ALL PRIVILEGES ON database_name.* TO 'me'@'localhost';
exit
service mysql restart
service mysql start
