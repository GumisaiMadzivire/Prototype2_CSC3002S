service mysql start
service mysql start
mysql -u root
USE mysql;
UPDATE mysql.user SET plugin='mysql_native_password' WHERE USER='root';
FLUSH PRIVILEGES;
exit
service mysql restart
service mysql start