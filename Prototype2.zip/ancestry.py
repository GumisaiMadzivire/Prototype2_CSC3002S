# ancestry script for prototype 2
# Gumisai Madzivire & Masechaba Khoza
# MDZGUM002 KHZMAS001

# Function is used to create a file with the same filename as the wcard(testfile)
# Within the current directory
# To store the parameters used by the GA
def createAncestryFile(file):
    filename = file[0:-6] + ".txt"
    f = open(filename, "w+")
    f.close()

# Function is used to write to file with the same filename as the wcard(testfile)
# Within the current directory
# To store the parameters used by the GA
def writeToAncestry(arr,file):
    filename = file[0:-6] + ".txt"
    f = open(filename, "a")
    for i in arr:
        f.write(str(i) + " ")
    f.write("\n")
    f.close()