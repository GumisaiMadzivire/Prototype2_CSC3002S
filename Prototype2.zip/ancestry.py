

def createAncestryFile(file):
    filename = file[0:-6] + ".txt"
    f = open(filename, "w+")
    f.close()

def writeToAncestry(arr,file):
    filename = file[0:-6] + ".txt"
    f = open(filename, "a")
    for i in arr:
        f.write(str(i) + " ")
    f.write("\n")
    f.close()