#Import modules for elementwize problem
#from _typeshed import Self
from typing import ValuesView
import numpy as np
import autograd.numpy as anp
from pymoo.util.misc import stack
from pymoo.core.problem import ElementwiseProblem ,starmap_parallelized_eval

#Import modules for DE
from pymoo.algorithms.soo.nonconvex.de import DE
from pymoo.operators.sampling.lhs import LHS
from pymoo.optimize import minimize
from pymoo.factory import get_termination

#Import for arguments passed to system
import sys

#Import for CarlSAT
import os
import subprocess

#Import for fileNames
import uuid

#import for Paralellization
import multiprocessing
from multiprocessing.pool import ThreadPool
import threading

#import for database
import mysql.connector

# pool is a global variable, that will not change during run
n_threads = multiprocessing.cpu_count()
pool = ThreadPool(n_threads)

# global variables used to stochastically select best output
count = 0
cTime = 0
scoreLow = 1000000
selectionArray = []
inLow = "words"
lock = threading.Lock()

#Define elementwise problem
class MyProblem(ElementwiseProblem):
    def __init__(self, *args, **kwargs):

        #20 values the problem will choose (0-19) for each parameter
        self.const_a = np.logspace(0, 3, 20)
        self.const_b = np.logspace(1, 6, 20)
        self.const_c = np.logspace(0, 3, 20)                   
        self.const_e = np.logspace(0, 3, 20)      
        self.const_f = np.logspace(0, 3, 20)                     
        self.const_r = np.logspace(0, 2, 20)
        self.const_x = np.logspace(0, 5, 20)
        
        # Obtain the args (filename and timeout) passed from the GA 
        self.initVar = args

        super().__init__(n_var=7,  
                         n_obj=2,
                         n_constr=0,
                         #                a        b     c      e     f     r       x    # we're picking from a list
                         xl = np.array([  0,       0,    0,     0,    0,    0,      0]), # lower bounds of vars
                         xu = np.array([ 19,  19,  19,   19,  19,   19,  19]), # upper bounds of vars
                         **kwargs
                         )


    def _evaluate(self, x, out , *args, **kwaargs):  #x is the list of parameters supplied by the GA algorithm (in this case DE)
        a =    int(self.const_a[round(x[0])])
        b =    int(self.const_b[round(x[1])])
        c =    int(self.const_c[round(x[2])])
        e =    int(self.const_e[round(x[3])])
        f =    int(self.const_f[round(x[4])])
        r =    int(self.const_r[round(x[5])])
        topx = int(self.const_x[round(x[6])])
        v = 3 

        # Obtain file name and timeout from the initialization of the function
        filetime = self.initVar[0]
        
        # Make an array of type int using the variables provided by the GA
        arr = [a,b,c,e,f,r,topx,v]
        arr = list(map(str, arr))

        # Create a outfile to write to using a UUID
        outfile = str(uuid.uuid4()) + ".out"

        # Global variables for parallelization of the prototype
        global count, scoreLow, inLow, selectionArray

        # If the count is less than 33 (For the first 32 runs of the GA)
        # The input file is the file provided by the user
        # Else the input file is the out file created
        count+=1
        if count<33:
            inputFile = filetime[0]
        else:
            inputFile = inLow
        arr.append(outfile)

        arrayC = callCarlSat(inputFile, arr, filetime[1])
        ancestryArray = arr
        inLow = arrayC[len(arrayC)-1]

        if (len(arrayC)==3):
            if arrayC[0] < scoreLow:
                lock.acquire()
                inLow = outfile
                lock.release()
            p1 = arrayC[0]
            out["F"] = p1
            
        elif (len(arrayC)==5):
            if arrayC[0] < scoreLow:
                lock.acquire()
                inLow = outfile
                lock.release()
            p1 = arrayC[1]
            p2 = arrayC[1]- arrayC[0]
            p3 = arrayC[3]- arrayC[2]
            out["F"] = p1

        writeToAncestry(ancestryArray,filetime[0])

# This function will call CarlSAT using the parameters passed from the GA, and the filename and timeout from the commandline
# In the case of CarlSAT2, it will divide the timeout by 32, to give runs of the file 
def callCarlSat(filename, arrParms, timeout):
    a = arrParms[0] #"2"
    b = arrParms[1] #"4"
    c = arrParms[2] 
    e = arrParms[3] 
    f = arrParms[4] 
    r = arrParms[5] 
    x = arrParms[6] 
    t = timeout
    v = arrParms[7] # should always be "3"
    z = filename
    w = arrParms[8]

    outFile = ".out"

    m = str(float(t)*1000/32)
    t = str(float(m)/1000)

    #If we find .out within the input filename, we use CarlSAT2's functionality
    if outFile in z:
        process = subprocess.run([os.path.join(os.getcwd(), 'CarlSAT'), '-a', a, '-b', b, '-c', c, '-e', e, '-f', f, '-r', r, '-x', x, '-m', m, '-v', v, '-i', z, '-w', w], cwd = os.getcwd(),
    capture_output=True).stdout
    #else we use the base functionality from CarlSAT1
    else:
        process = subprocess.run([os.path.join(os.getcwd(), 'CarlSAT'), '-a', a, '-b', b, '-c', c, '-e', e, '-f', f, '-r', r, '-x', x, '-t', t, '-v', v, '-z', z, '-w', w], cwd = os.getcwd(),
    capture_output=True).stdout

    #conversion of bytes to string
    data = process.decode()
    
    data = data[data.find(".out")+4:-1]

    outExists = data.find(".out")

    carlSATOutArray = data.split()

    if (outExists != -1):
        startCostIndex = carlSATOutArray.index("Intermediate:") +3   #A
        strStartCost = carlSATOutArray[startCostIndex]
        startCost = int(strStartCost.replace(',',''), base=10)

        endCostIndex = carlSATOutArray.index("UNKNOWN")+2            #B
        strEndCost = carlSATOutArray[endCostIndex]
        endCost = int(strEndCost.replace(',',''), base=10)

        timeToScoreIndex = carlSATOutArray.index("Time:")+1          #C
        timeToScore = carlSATOutArray[timeToScoreIndex]
        tts = round(float(timeToScore)*1000, 3)

        timeoutIndex = carlSATOutArray.index("Timeout") +2           #D
        strTimeout = carlSATOutArray[timeoutIndex]
        timeout = int(strTimeout.replace(',',''), base=10)

        obj = [startCost, endCost, tts, timeout, w]
        return obj

    else:
        strCostIndex = carlSATOutArray.index('o')+1
        strCost = carlSATOutArray[strCostIndex]
        cost = int(strCost.replace(',',''), base=10)

        #converting time to float
        strTimeIndex = carlSATOutArray.index("Time:")+1
        strTime = carlSATOutArray[strTimeIndex]
        time = float(strTime)

        obj = [cost, time, w]
    
        return obj

def createAncestryFile(file):
    filename = file[0:-6] + ".txt"
    f = open(filename, "w+")
    f.close()

def writeToAncestry(arr,file):
    filename = file[0:-6] + ".txt"
    f = open(filename, "a")
    for i in arr:
        f.write(str(i) + " ")
    f.write("\n")
    f.close()

# Genetic algorithm
def geneticAlgorithm(filename, timeout):

    # Test whether filename and timeout is valid
    if (filename.find(".wcard") == -1):
        raise TypeError("Filename is incorrect")
    
    if (timeout != "1" and timeout != "2" and timeout != "10"):                     # If the timeout is not "1","2" or "10", send an error with the correct syntax
        raise ValueError("Timeout must be either 1, 2 or 10")

    # Initialize problem
    initVar = [filename, timeout]
    problem = MyProblem(initVar, runner=pool.starmap, func_eval=starmap_parallelized_eval)         # Problem assignment, with parallelization using starmap 

    termination = get_termination("n_gen", 32)                               # After 32 Generations, stop the pymoo

    # Initialize algorithm
    algorithm = DE(
        pop_size= 32,                                                        # 32 this is the number of items that are sampled per generation. Each generation, the best go though, and are used to construct new offspring.
        sampling=LHS(), # Defines the initial set of solutions which are the starting point of the optimization
        variant="DE/rand/1/bin",                                             # The different variants of DE to be used.
        CR=0.5,                                                              # Probability the individual exchanges variable values from the donor vector
        F=0.3,                                                               # Crossover weight
        dither="vector",                                                     # Different individual used one for each individual
        jitter=False                                                         # Strategy for adaptive weights (F). A very small value is added or subtracted to the weight used for the crossover for each individual
    )


    #Optimize with minimize
    res = minimize(problem,                                                  # The problem defined above
                algorithm,                                                   # The algorithm provided by pymoo
                termination,                                                 # Tells the program when it needs to stop running
                seed = 1,                                                    # Tells the 
                save_history = True,                                         # For diagnostics
                verbose = True                                               # Shows the programs processing if set to 'True'
    )
    return res.X

def createDatabase():
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root"
    )

    mycursor = db.cursor()
    code = "CREATE DATABASE IF NOT EXISTS statefiles"

    mycursor.execute(code)

    return db

def createTable(filename, db):
    mycursor = db.cursor()

    mycursor.execute("USE statefiles;")
    code = "CREATE TABLE "+ filename[0:-6] + " (id integer primary key auto-increment not null, a, b, c, e, f, r, x, m, v, i, z, w, P1, P2, P3, filename);"
    mycursor.execute(code)

    code = "CREATE TABLE ids ( id integer primary key auto-increment not null, thread_id integer not null );"
    mycursor.execute(code)

def addToTable(filename, arr, db):
    mycursor = db.cursoe()

    code = ("INSERT INTO " + filename + "(id, a, b, c, e, f, r, x, m, v, i, z, w, A, E, F) VALUES ({%s}{%s}{%s}{%s}{%s}{%s}{%s}{%s}{%s}{%s}{%s}{%s}{%s}{%s}{%s}{%s}",
    (arr[0],arr[1],arr[2],arr[3],arr[4],arr[5],arr[6],arr[7],arr[8],arr[9],arr[10],arr[11],arr[12],arr[13],arr[14],arr[15]))

    mycursor.execute(code)



#main function
if __name__ == '__main__':

    n = len(sys.argv)
    if (n == 3):

    # Prompt user for filename and timeout
        filename = sys.argv[1]                                                              # Gets the filename from the second argument passed in the console
        timeout = sys.argv[2]                                                               # Gets the timeout from the third argument passed in the console

        if (filename.find(".wcard") == -1):                                                 # If the filename does not contain .wcard, send an error with the correct syntax
            raise TypeError("Correct syntax is \'python3 prototype1 [wcard] [timeout]\'")
        #elif 
        if (timeout != "1" and timeout != "2" and timeout != "10"):                           # If the timeout is not "1","2" or "10", send an error with the correct syntax
            raise ValueError("Timeout must be either 1, 2 or 10")

        print("Starting HyperOptimizer....")

        db = createDatabase()
        createTable(filename, db)

        createAncestryFile(filename)
        output = geneticAlgorithm(filename, timeout)
        output = output.round()
        arr = output.tolist()

        target = "/ramdisk/"

        os.system("sudo mv *.out "+ target)

        print(selectionArray)

    else:
        raise SyntaxError("Correct syntax to start is \'python3 prototype1 [wcard] [timeout]\'")

    